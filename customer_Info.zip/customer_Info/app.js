//app.js
App({
  host:{
    url:"http://127.0.0.1:8086/wudi/"
  }
})